'use strict';

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _serverRoutesApiIngest = require('./server/routes/api/ingest');

var _serverRoutesApiIngest2 = _interopRequireDefault(_serverRoutesApiIngest);

var _serverRoutesApiSearch = require('./server/routes/api/search');

var _serverRoutesApiSearch2 = _interopRequireDefault(_serverRoutesApiSearch);

var _serverRoutesApiSettings = require('./server/routes/api/settings');

var _serverRoutesApiSettings2 = _interopRequireDefault(_serverRoutesApiSettings);

module.exports = function (kibana) {
  return new kibana.Plugin({
    id: 'kibana',
    config: function config(Joi) {
      return Joi.object({
        enabled: Joi.boolean()['default'](true),
        defaultAppId: Joi.string()['default']('discover'),
        index: Joi.string()['default']('.kibana')
      })['default']();
    },

    uiExports: {
      app: {
        id: 'kibana',
        title: 'Kibana',
        listed: false,
        description: 'the kibana you know and love',
        main: 'plugins/kibana/kibana',
        uses: ['visTypes', 'spyModes', 'fieldFormats', 'navbarExtensions', 'managementSections', 'docViews'],

        injectVars: function injectVars(server, options) {
          var config = server.config();
          return {
            kbnDefaultAppId: config.get('kibana.defaultAppId'),
            tilemap: config.get('tilemap')
          };
        }
      },

      links: [{
        id: 'kibana:discover',
        title: 'Discover',
        order: -1003,
        url: '/app/kibana#/discover',
        description: 'interactively explore your data',
        icon: 'plugins/kibana/assets/discover.svg'
      }, {
        id: 'kibana:visualize',
        title: 'Visualize',
        order: -1002,
        url: '/app/kibana#/visualize',
        description: 'design data visualizations',
        icon: 'plugins/kibana/assets/visualize.svg'
      }, {
        id: 'kibana:dashboard',
        title: 'Dashboard',
        order: -1001,
        url: '/app/kibana#/dashboard',
        description: 'compose visualizations for much win',
        icon: 'plugins/kibana/assets/dashboard.svg'
      }, {
        id: 'kibana:management',
        title: 'Management',
        order: 1000,
        url: '/app/kibana#/management',
        description: 'define index patterns, change config, and more',
        icon: 'plugins/kibana/assets/settings.svg',
        linkToLastSubUrl: false
      }],
      injectDefaultVars: function injectDefaultVars(server, options) {
        return {
          kbnIndex: options.index
        };
      }
    },

    init: function init(server, options) {
      (0, _serverRoutesApiIngest2['default'])(server);
      (0, _serverRoutesApiSearch2['default'])(server);
      (0, _serverRoutesApiSettings2['default'])(server);
    }
  });
};
