'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});
exports.registerData = registerData;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _bluebird = require('bluebird');

var _csvParse = require('csv-parse');

var _csvParse2 = _interopRequireDefault(_csvParse);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _highland = require('highland');

var _highland2 = _interopRequireDefault(_highland);

var _commonLibConvert_pattern_and_ingest_name = require('../../../../common/lib/convert_pattern_and_ingest_name');

var _stream = require('stream');

var _JSONStream = require('JSONStream');

var _JSONStream2 = _interopRequireDefault(_JSONStream);

var ONE_GIGABYTE = 1024 * 1024 * 1024;

function registerData(server) {
  server.route({
    path: '/api/kibana/{id}/_data',
    method: 'POST',
    config: {
      payload: {
        output: 'stream',
        maxBytes: ONE_GIGABYTE
      }
    },
    handler: function handler(req, reply) {
      var boundCallWithRequest = _lodash2['default'].partial(server.plugins.elasticsearch.callWithRequest, req);
      var indexPattern = req.params.id;
      var usePipeline = req.query.pipeline === 'true';
      var delimiter = _lodash2['default'].get(req.query, 'csv_delimiter', ',');
      var responseStream = new _stream.PassThrough();
      var parser = (0, _csvParse2['default'])({
        columns: true,
        auto_parse: true,
        delimiter: delimiter,
        skip_empty_lines: true
      });

      var csv = req.payload.csv ? req.payload.csv : req.payload;
      var fileName = req.payload.csv ? csv.hapi.filename : '';

      var currentLine = 2; // Starts at 2 since we parse the header separately

      csv.pipe(parser);

      (0, _highland2['default'])(parser).consume(function (err, doc, push, next) {
        if (err) {
          push(err, null);
          next();
        } else if (doc === _highland2['default'].nil) {
          // pass nil (end event) along the stream
          push(null, doc);
        } else {
          push(null, { index: _lodash2['default'].isEmpty(fileName) ? {} : { _id: fileName + ':' + currentLine } });
          push(null, doc);
          currentLine++;
          next();
        }
      }).batch(200).map(function (bulkBody) {
        var bulkParams = {
          index: indexPattern,
          type: 'default',
          body: bulkBody
        };

        if (usePipeline) {
          bulkParams.pipeline = (0, _commonLibConvert_pattern_and_ingest_name.patternToIngest)(indexPattern);
        }

        return (0, _highland2['default'])(boundCallWithRequest('bulk', bulkParams));
      }).parallel(2).map(function (response) {
        return _lodash2['default'].reduce(response.items, function (memo, docResponse) {
          var indexResult = docResponse.index;
          if (indexResult.error) {
            var hasIndexingErrors = _lodash2['default'].isUndefined(_lodash2['default'].get(memo, 'errors.index'));
            if (hasIndexingErrors) {
              _lodash2['default'].set(memo, 'errors.index', []);
            }
            memo.errors.index.push(_lodash2['default'].pick(indexResult, ['_id', 'error']));
          } else {
            memo.created++;
          }

          return memo;
        }, { created: 0 });
      }).stopOnError(function (err, push) {
        push(null, { created: 0, errors: { other: [err.message] } });
      }).pipe(_JSONStream2['default'].stringify()).pipe(responseStream);

      reply(responseStream).type('application/json');
    }
  });
}
