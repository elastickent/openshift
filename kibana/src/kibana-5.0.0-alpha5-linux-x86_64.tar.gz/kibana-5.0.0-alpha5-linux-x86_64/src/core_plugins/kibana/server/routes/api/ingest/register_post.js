'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});
exports.registerPost = registerPost;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

var _boom = require('boom');

var _boom2 = _interopRequireDefault(_boom);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _libSchemasResourcesIngest_config_schema = require('../../../lib/schemas/resources/ingest_config_schema');

var _libSchemasResourcesIngest_config_schema2 = _interopRequireDefault(_libSchemasResourcesIngest_config_schema);

var _libHandle_es_error = require('../../../lib/handle_es_error');

var _libHandle_es_error2 = _interopRequireDefault(_libHandle_es_error);

var _libCreate_mappings_from_pattern_fields = require('../../../lib/create_mappings_from_pattern_fields');

var _libCreate_mappings_from_pattern_fields2 = _interopRequireDefault(_libCreate_mappings_from_pattern_fields);

var _libInit_default_field_props = require('../../../lib/init_default_field_props');

var _libInit_default_field_props2 = _interopRequireDefault(_libInit_default_field_props);

var _commonLibConvert_pattern_and_ingest_name = require('../../../../common/lib/convert_pattern_and_ingest_name');

var _commonLibCase_conversion = require('../../../../common/lib/case_conversion');

var _libConvertersIngest_pipeline_api_kibana_to_es_converter = require('../../../lib/converters/ingest_pipeline_api_kibana_to_es_converter');

var _libConvertersIngest_pipeline_api_kibana_to_es_converter2 = _interopRequireDefault(_libConvertersIngest_pipeline_api_kibana_to_es_converter);

function registerPost(server) {
  var kibanaIndex = server.config().get('kibana.index');

  function patternRollback(rootError, indexPatternId, boundCallWithRequest) {
    var deleteParams = {
      index: kibanaIndex,
      type: 'index-pattern',
      id: indexPatternId
    };

    return boundCallWithRequest('delete', deleteParams).then(function () {
      throw rootError;
    }, function (patternDeletionError) {
      throw new Error('index-pattern ' + indexPatternId + ' created successfully but index template or pipeline\n                creation failed. Failed to rollback index-pattern creation, must delete manually.\n                ' + patternDeletionError.toString() + '\n                ' + rootError.toString());
    });
  }

  function templateRollback(rootError, templateName, boundCallWithRequest) {
    var deleteParams = {
      name: templateName
    };

    return boundCallWithRequest('indices.deleteTemplate', deleteParams).then(function () {
      throw rootError;
    }, function (templateDeletionError) {
      throw new Error('index template ' + templateName + ' created successfully but pipeline\n                creation failed. Failed to rollback template creation, must delete manually.\n                ' + templateDeletionError.toString() + '\n                ' + rootError.toString());
    });
  }

  server.route({
    path: '/api/kibana/ingest',
    method: 'POST',
    config: {
      validate: {
        payload: _libSchemasResourcesIngest_config_schema2['default']
      }
    },
    handler: _asyncToGenerator(function* (req, reply) {
      var uiSettings = server.uiSettings();
      var metaFields = yield uiSettings.get('metaFields');
      var boundCallWithRequest = _lodash2['default'].partial(server.plugins.elasticsearch.callWithRequest, req);
      var requestDocument = _lodash2['default'].cloneDeep(req.payload);
      var indexPattern = (0, _commonLibCase_conversion.keysToCamelCaseShallow)(requestDocument.index_pattern);
      var indexPatternId = indexPattern.id;
      var ingestConfigName = (0, _commonLibConvert_pattern_and_ingest_name.patternToIngest)(indexPatternId);
      var shouldCreatePipeline = !_lodash2['default'].isEmpty(requestDocument.pipeline);
      delete indexPattern.id;

      var mappings = (0, _libCreate_mappings_from_pattern_fields2['default'])(indexPattern.fields);
      var indexPatternMetaFields = _lodash2['default'].map(metaFields, function (name) {
        return { name: name };
      });

      indexPattern.fields = (0, _libInit_default_field_props2['default'])(indexPattern.fields.concat(indexPatternMetaFields));
      indexPattern.fields = JSON.stringify(indexPattern.fields);
      indexPattern.fieldFormatMap = JSON.stringify(indexPattern.fieldFormatMap);

      var pipeline = (0, _libConvertersIngest_pipeline_api_kibana_to_es_converter2['default'])(requestDocument.pipeline);

      // Set up call with request params
      var patternCreateParams = {
        index: kibanaIndex,
        type: 'index-pattern',
        id: indexPatternId,
        body: indexPattern
      };

      var templateParams = {
        order: 1,
        create: true,
        name: ingestConfigName,
        body: {
          template: indexPatternId,
          mappings: {
            _default_: {
              properties: mappings
            }
          }
        }
      };

      var pipelineParams = {
        path: '/_ingest/pipeline/' + ingestConfigName,
        method: 'PUT',
        body: pipeline
      };

      return boundCallWithRequest('indices.exists', { index: indexPatternId }).then(function (matchingIndices) {
        if (matchingIndices) {
          throw _boom2['default'].conflict('Cannot create an index pattern via this API if existing indices already match the pattern');
        }

        return boundCallWithRequest('create', patternCreateParams).then(function () {
          return boundCallWithRequest('indices.putTemplate', templateParams)['catch'](function (templateError) {
            return patternRollback(templateError, indexPatternId, boundCallWithRequest);
          });
        }).then(function (templateResponse) {
          if (!shouldCreatePipeline) {
            return templateResponse;
          }

          return boundCallWithRequest('transport.request', pipelineParams)['catch'](function (pipelineError) {
            return templateRollback(pipelineError, ingestConfigName, boundCallWithRequest);
          })['catch'](function (templateRollbackError) {
            return patternRollback(templateRollbackError, indexPatternId, boundCallWithRequest);
          });
        });
      }).then(function () {
        reply().code(204);
      }, function (error) {
        reply((0, _libHandle_es_error2['default'])(error));
      });
    })
  });
}

;
