'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _register_post = require('./register_post');

var _register_delete = require('./register_delete');

var _register_processors = require('./register_processors');

var _register_simulate = require('./register_simulate');

var _register_data = require('./register_data');

exports['default'] = function (server) {
  (0, _register_post.registerPost)(server);
  (0, _register_delete.registerDelete)(server);
  (0, _register_processors.registerProcessors)(server);
  (0, _register_simulate.registerSimulate)(server);
  (0, _register_data.registerData)(server);
};

module.exports = exports['default'];
