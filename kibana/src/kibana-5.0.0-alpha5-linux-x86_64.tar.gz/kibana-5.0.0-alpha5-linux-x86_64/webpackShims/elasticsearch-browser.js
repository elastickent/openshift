'use strict';

require('angular');
module.exports = require('elasticsearch-browser/elasticsearch.angular.js');
require('ui/modules').get('kibana', ['elasticsearch']);
