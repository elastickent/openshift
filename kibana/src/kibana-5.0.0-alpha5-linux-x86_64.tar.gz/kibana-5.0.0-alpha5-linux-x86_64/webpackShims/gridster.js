'use strict';

require('jquery');
require('node_modules/gridster/dist/jquery.gridster.css');
require('script!node_modules/gridster/dist/jquery.gridster');
